package edu.CECAR.test;

import edu.CECAR.logicaNegocio.Cliente;

public class TestCliente {

	public static void main(String[] args) {
		
		new Cliente("127.0.0.1", 17000);

	}

}
