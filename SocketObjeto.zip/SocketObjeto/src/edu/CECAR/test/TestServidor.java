package edu.CECAR.test;

import edu.CECAR.logicaNegocio.ServidorArchivo;

public class TestServidor {

		public static void main(String[] args) {
			new ServidorArchivo(17000);
		}
}
